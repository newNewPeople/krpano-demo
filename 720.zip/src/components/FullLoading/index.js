import FullLoading from './loading';
export default FullLoading;
