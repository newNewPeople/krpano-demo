const getters = {
  videoStatus: state => state.user.videoStatus
}

export default getters